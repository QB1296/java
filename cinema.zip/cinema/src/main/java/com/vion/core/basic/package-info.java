/**
 * 文件名：package-info.java  
 *  
 * 版本信息：  
 * 日期：2014年8月8日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

/**
 * <b>功能描述</b> <br>
 * 业务服务层,包含基础库的维护
 * @author YUJB
 * @date 2014年8月8日 下午3:32:48
 */
package com.vion.core.basic;