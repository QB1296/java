package com.vion.core.model;

/**
 * <b>功能描述</b> <br>
 * 操作成功结构体 
 * @see ReplyModel
 * @author YUJB
 * @date 2014年5月12日 下午5:51:31
 */
public class SuccessedReplyModel extends ReplyModel{

	/* (non-Javadoc)
	 * @see com.css.bdp.core.model.ResultReplyModel#getSuccess()*/
	@Override
	public boolean getSuccess() {
		return true;
	}
	
	
}
