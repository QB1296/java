/**
 * 文件名：package-info.java  
 *  
 * 版本信息：  
 * 日期：2014-5-11  
 * Copyright(c) 2013 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

/**
 * <b>功能描述</b> <br>
 * Spring 的扩展包
 * @author YUJB
 */
package com.vion.core.spring;