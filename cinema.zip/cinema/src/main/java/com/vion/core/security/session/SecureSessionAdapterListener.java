/**
 * 文件名：SecureSessionAdapterListener.java  
 *  
 * 版本信息：  
 * 日期：2014年11月4日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.security.session;

/**
 * <b>功能描述</b> <br>
 * session 监听适配器,为监听器的一个存根stub.所有方法均为空实现
 * @author YUJB
 * @date 2014年11月4日 下午1:54:05
 */
public class SecureSessionAdapterListener implements SecureSessionListener{

	@Override
	public void onCreate(SecureSession secureSession) {
		
	}

	@Override
	public void onExpire(SecureSession secureSession) {
		
	}

	@Override
	public void onChange(SecureSession secureSession) {
		
	}

	@Override
	public void onTouch(SecureSession secureSession) {
		
	}

}
