/**
 * 文件名：package-info.java  
 *  
 * 版本信息：  
 * 日期：2014年8月8日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

/**
 * <b>功能描述</b> <br>
 * 领域模型.主要分IEntity（实体）、和ValueObject（值对象）
 * 同时包括树形结构、{@link com.vion.core.domain.ExtLoaderResolver}
 * @author YUJB
 * @date 2014年8月8日 下午3:32:48
 */
package com.vion.core.domain;