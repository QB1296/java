/**
 * 文件名：SortedAble.java  
 *  
 * 版本信息：  
 * 日期：2015年1月20日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core;

/**
 * <b>功能描述</b> <br>
 * 如果需要排序择需要实现此接口,实现{@link #sortNumber()}方法
 * @author YUJB
 * @date 2015年1月20日 上午9:38:49
 */
public interface SortedAble {

	/**
	 * 排序号,按照升序排列
	 * @return
	 */
	public Integer sortNumber();
}
