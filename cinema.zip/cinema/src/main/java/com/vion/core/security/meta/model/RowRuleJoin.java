/**
 * 文件名：SubEntityModel.java  
 *  
 * 版本信息：  
 * 日期：2014年8月12日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.security.meta.model;

import org.apache.commons.digester.annotations.rules.ObjectCreate;
import org.apache.commons.digester.annotations.rules.SetProperty;


/**
 * <b>功能描述</b> <br>
 *
 * @author YUJB
 * @date 2014年8月12日 上午11:54:27
 */
@ObjectCreate(pattern="premission-mapping/moudle/rowRule/join")
public class RowRuleJoin{
	
	@SetProperty(attributeName="name",pattern="premission-mapping/moudle/rowRule/join")
	private String name;
	
	@SetProperty(attributeName="forceJoin",pattern="premission-mapping/moudle/rowRule/join")
	private String forceJoin;
	
	@SetProperty(attributeName="joinSQL",pattern="premission-mapping/moudle/rowRule/join")
	private String joinSQL;
	
	
	@SetProperty(attributeName="joinType",pattern="premission-mapping/moudle/rowRule/join")
	private String joinType;
	
	
	/**
	 * {@link #joinType}
	 * @return the joinType
	 */
	public String getJoinType() {
		return joinType;
	}

	/**
	 * {@link #joinType}	
	 * @param joinType the joinType to set
	 */
	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}

	/**
	 * {@link #name}
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * {@link #name}	
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * {@link #forceJoin}
	 * @return the forceJoin
	 */
	public String getForceJoin() {
		return forceJoin;
	}

	/**
	 * {@link #forceJoin}	
	 * @param forceJoin the forceJoin to set
	 */
	public void setForceJoin(String forceJoin) {
		this.forceJoin = forceJoin;
	}

	/**
	 * {@link #joinSQL}
	 * @return the joinSQL
	 */
	public String getJoinSQL() {
		return joinSQL;
	}

	/**
	 * {@link #joinSQL}	
	 * @param joinSQL the joinSQL to set
	 */
	public void setJoinSQL(String joinSQL) {
		this.joinSQL = joinSQL;
	}
	
	
}
