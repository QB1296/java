/**
 * 
 */
package com.vion.core.security;

/**
 * @author YUJB
 *
 */
public interface SQLProcessor {
	
	public String processorSQL(Object value,String sql);
	
	
}
