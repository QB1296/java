/**
 * 文件名：ExcelImportLinsitor.java  
 *  
 * 版本信息：  
 * 日期：2015年1月28日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.poi;


/**
 * <b>功能描述</b> <br>
 * excel导出监听器
 * @author YUJB
 * @date 2015年1月28日 上午9:18:24
 */
public interface ExcelExportListener {
	
	void importStart(String sheetName);
	
	void importing(int row,int count,String sheetName);
	
	void importEnd(String sheetName);
}
