/**
 * 
 */
package com.vion.core.security;


/**
 * <b>功能描述</b> <br>
 * SQL数据验证值处理器,比如Date必须使用 "to_date('" + value.toString()+ "','yyyy-mm-dd hh24:mi:ss'')";
 * 处理Value 
 * @author YUJB
 * @date 2015年1月20日 上午9:57:07
 */
public interface ValueProcessor {
	
	public String processorValue(Object value);
	
	
}
