/**
 * 文件名：OriginPagedResult.java  
 *  
 * 版本信息：  
 * 日期：2014年6月13日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.dao.page;


/**
 * <b>功能描述</b> <br>
 * 原始的PagedResult,其中{@link #getResults()}返回的是Object对象
 * @author YUJB
 * @date 2014-6-14 下午3:39:04
 */
public class OriginPagedResult {

	private Object results;
	
	private IPage page;


	public Object getResults() {
		return results;
	}

	public void setResults(Object results) {
		this.results = results;
	}

	public IPage getPage() {
		return page;
	}

	public void setPage(IPage page) {
		this.page = page;
	}
}
