/**
 * 文件名：ExceptionConvert.java  
 *  
 * 版本信息：  
 * 日期：2014年6月16日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.spring;

import com.vion.core.exception.SpiderBussinessException;

/**
 * <b>功能描述</b> <br>
 *
 * @author YUJB
 * @date 2014年6月16日 上午9:52:49
 */
public interface SpiderBusinessExceptionConvert<T extends Exception> {
	
	SpiderBussinessException convert(T e);

}
