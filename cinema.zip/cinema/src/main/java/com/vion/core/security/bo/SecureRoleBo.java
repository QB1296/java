/**
 * 文件名：SecureRoleBo.java  
 *  
 * 版本信息：  
 * 日期：2014年10月27日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.security.bo;



/**
 * <b>功能描述</b> <br>
 * 权限角色BO
 * @author YUJB
 * @date 2014年10月27日 上午10:52:56
 */
public class SecureRoleBo {
	
	private String id;
	
    private String name;
    
    private String system;
    
    private String isDefault;
    
    private String description;

	/**
	 * 获得id 
	 * @return  id id
	 */
	public String getId() {
		return id;
	}

	/** 
	 * 设置id 
	 * @param id id 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 获得name 
	 * @return  name name
	 */
	public String getName() {
		return name;
	}

	/** 
	 * 设置name 
	 * @param name name 
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 获得system 
	 * @return  system system
	 */
	public String getSystem() {
		return system;
	}

	/** 
	 * 设置system 
	 * @param system system 
	 */
	public void setSystem(String system) {
		this.system = system;
	}

	/**
	 * 获得isDefault 
	 * @return  isDefault isDefault
	 */
	public String getIsDefault() {
		return isDefault;
	}

	/** 
	 * 设置isDefault 
	 * @param isDefault isDefault 
	 */
	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	/**
	 * 获得description 
	 * @return  description description
	 */
	public String getDescription() {
		return description;
	}

	/** 
	 * 设置description 
	 * @param description description 
	 */
	public void setDescription(String description) {
		this.description = description;
	}
    
    

	
}
