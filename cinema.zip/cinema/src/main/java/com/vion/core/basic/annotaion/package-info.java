/**
 * 文件名：package-info.java  
 *  
 * 版本信息：  
 * 日期：2015年1月29日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

/**
 * <b>功能描述</b> <br>
 *
 * @author YUJB
 * @date 2015年1月29日 上午9:25:12
 */
package com.vion.core.basic.annotaion;