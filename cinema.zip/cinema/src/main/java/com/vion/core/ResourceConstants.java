package com.vion.core;

/**
 * <b>功能描述</b> <br>
 *
 * @author YUJB
 * @date 2014年6月26日 上午10:43:41
 */
public class ResourceConstants {
	
	public static final String FLT_CLASS = "^.+[.]class$";
	
	public static final String PERFIX_FILE_URL = "file:";
	
	public static final String CONTAIN_JAR_URL = "jar!";
	
	public static final String PERFIX_JAR_URL = "jar:file:";
	
	public static final String SUFFIX_JAR_URL = ".jar";
	
	public static final String JAR_URL_SEPARATOR = "!/";
}