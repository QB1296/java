/**
 * 文件名：package-info.java  
 *  
 * 版本信息：  
 * 日期：2014年5月12日  
 * Copyright(c) 2013 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

/**
 * <b>功能描述</b> <br>
 * 基础模型
 * @author YUJB
 */
package com.vion.core.model;