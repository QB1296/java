/**
 * 文件名：package-info.java  
 *  
 * 版本信息：  
 * 日期：2015年4月16日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

/**
 * <b>提供数据转换功能</b>
 * @author GANJX
 *
 */
package com.vion.core.hibernate.converter;