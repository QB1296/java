/**

 * 文件名：IEntity.java  
 *  
 * 版本信息：  
 * 日期：2014-6-5  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.domain.entity;

import java.io.Serializable;

/**
 * <b>功能描述</b> <br>
 * 实体标识字段，所有持久化实体必须实现此接口
 * @author YUJB
 * @date 2014-6-5 上午10:29:44
 */
public interface IEntity extends Serializable{

	
}
