/**
 * 文件名：Sort.java  
 *  
 * 版本信息：  
 * 日期：2013-6-5  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */

package com.vion.core.dao.finder;


/**
 * <b>功能描述</b> <br>
 * 排序
 * @author YUJB
 * @date 2014-6-5 下午01:08:33
 */
public class Group implements IGroup{

	/** 排序字段名称  */
	protected String[] propertys;
	
	private IFilter having;


	/**
	 * {@link #propertys}
	 * @return the propertys
	 */
	public String[] getProperties() {
		return propertys;
	}

	/**
	 * {@link #propertys}	
	 * @param propertys the propertys to set
	 */
	public void setPropertys(String... propertys) {
		this.propertys = propertys;
	}

	/**
	 * {@link #having}
	 * @return the having
	 */
	public IFilter getHaving() {
		return having;
	}

	/**
	 * {@link #having}	
	 * @param having the having to set
	 */
	public void setHaving(IFilter having) {
		this.having = having;
	}
	
	
	
	

}
