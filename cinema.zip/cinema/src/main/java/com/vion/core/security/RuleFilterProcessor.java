/**
 * 文件名：RuleFilterProcessor.java  
 *  
 * 版本信息：  
 * 日期：2014年8月11日  
 * Copyright(c) 2014 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */	
 
package com.vion.core.security;


/**
 * <b>功能描述</b> <br>
 *
 * @author YUJB
 * @date 2014年8月11日 下午3:46:16
 */
public interface RuleFilterProcessor {
	
	public String process(String sql,Object ticket);
	
	public void cacheFilter(Object rowInfo,Object ticket);
}
