/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.ganjx.cinema.util;