/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.ganjx.cinema.vo;