/**
 * 文件名： IMapService.java
 *  
 * 版本信息：  
 * 日期：2015年4月13日 
 * Copyright(c) 2015 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */
package com.ganjx.cinema.basic.map;
/**
 * <b>功能描述</b> <br>
 * 
 * @author GANJX
 * @date 2015年4月13日 下午2:45:01
 */
public interface IMapService {

	/**
	 * 地图接口
	 * 根据名称获取经纬度
	 * @param address
	 * @return
	 */
	public BaiduMapResponse getLocationByAddress(String address);
}
