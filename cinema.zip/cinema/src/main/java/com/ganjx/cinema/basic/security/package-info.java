/**
 * 
 * @author GANJX
 * @version 1.0
 */
package com.ganjx.cinema.basic.security;