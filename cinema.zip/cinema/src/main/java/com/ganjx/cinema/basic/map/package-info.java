/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.ganjx.cinema.basic.map;