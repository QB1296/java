/**   
 * @Title: package-info.java 
 * @Package com.ganjx.cinema.vo.address1905 
 * @Description: TODO
 * @author ganjianxin   
 * @date 2015年10月17日 下午12:15:47 
 * @version V1.0   
 */
/** 
 * @ClassName: package-info 
 * @Description: TODO
 * @author ganjx 
 * @date 2015年10月17日 下午12:15:47 
 *  
 */
package com.ganjx.cinema.vo.address1905;