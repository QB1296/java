package com.ganjx.cinema.vo.address1905.info;

import java.io.Serializable;

public class Minprice implements Serializable{	private static final long serialVersionUID = 745536713L;	private String info;	private long code;	private String message;
	public String getInfo() {		return this.info;	}
	public void setInfo(String info) {		this.info = info;	}
	public long getCode() {		return this.code;	}
	public void setCode(long code) {		this.code = code;	}
	public String getMessage() {		return this.message;	}
	public void setMessage(String message) {		this.message = message;	}
	public Minprice() {}
	public Minprice(String info, long code, String message){
		super();		this.info = info;		this.code = code;		this.message = message;
	}
	public String toString() {
		return "Minprice [info = " + info + ", code = " + code + ", message = " + message + "]";	}
}