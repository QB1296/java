/**
 * 
 */
/**
 * @author GANJX
 *
 */
package com.ganjx.cinema.vo.mtime;