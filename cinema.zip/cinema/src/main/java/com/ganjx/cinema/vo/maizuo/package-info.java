/**
 * @author GANJX
 *
 */
package com.ganjx.cinema.vo.maizuo;