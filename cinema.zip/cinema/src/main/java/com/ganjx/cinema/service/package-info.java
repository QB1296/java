/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.ganjx.cinema.service;