/**
 * 文件名： JSoupMain.java
 *  
 * 版本信息：  
 * 日期：2015年10月8日 
 * Copyright(c) 2015 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */
package com.ganjx.cinema.basic.jsoup;

import java.io.IOException;
import java.util.List;
import java.util.ListIterator;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ganjx.cinema.entity.TCinemaAddress;

/**
 * <b>功能描述</b> <br>
 * 
 * @author GANJX
 * @date 2015年10月8日 下午3:30:09
 */
public class JSoupMain {

	static Logger logger = LoggerFactory.getLogger(JSoupMain.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Document doc;
        try {
//        	System.setProperty("http.proxyHost", "127.0.0.1");
//        	System.setProperty("http.proxyPort", "60203");
        	Connection connect = Jsoup.connect("http://beijing.lashou.com/movies/cinemalist/type0/page2");
        	connect.timeout(60*1000);
            doc = connect.get();
            Elements select = doc.select(".cliema-info");
            for (Element element : select) {
				String cinemaName = element.select("h3 a").text();
				Elements select2 = element.select("dl dd");
				String address = select2.select("span").text();
				Elements select3 = select2.select("a");
				String lng = select3.attr("data-lng");
				String lat = select3.attr("data-lat");
				logger.info("{},{},{},{}",cinemaName,address,lng,lat);
			}
            
            Elements select2 = doc.select(".page2 a");
            Element element2 = select2.get(select2.size()-2);
            String totalString = element2.text();
            logger.info("{}",totalString);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		 
	}
}
