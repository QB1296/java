/**
 * 文件名： MtimeService.java
 *  
 * 版本信息：  
 * 日期：2015年10月26日 
 * Copyright(c) 2015 VIONVISION &  CO.,LTD , http://www.vion-tech.com/ <br>
 * 版权所有  
 */
package com.ganjx.cinema.service;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vion.core.dao.IGeneralDAO;

/**
 * <b>功能描述</b> <br>
 * 
 * @author GANJX
 * @date 2015年10月26日 下午5:06:18
 */
@Service
@Transactional
public class MtimeService {
	Logger logger = LoggerFactory.getLogger(MtimeService.class);
	
	@Autowired
	IGeneralDAO generalDAO;
	
	public void readCity(){
		Document doc;
        try {
        	Connection connect = Jsoup.connect("http://theater.mtime.com/China_Beijing/");
        	connect.timeout(60*1000);
            doc = connect.get();
            Elements select = doc.select(".p15 a");
            for (Element element : select) {
            	logger.info(element.attr("value")+","+element.text());
            	
			}
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}
}
